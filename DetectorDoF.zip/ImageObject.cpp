#include "ImageObject.h"

ImageObject::ImageObject()
{
}


ImageObject::~ImageObject()
{
}

void ImageObject::Show(char *name, IplImage *img)
{
	cvShowImage(name, img);
}

void ImageObject::Show(char *name, cv::Mat &mat)
{
	cv::imshow(name, mat);
}

cv::Mat ImageObject::ConvertToMat(IplImage *img)
{
	return cv::cvarrToMat(img);
}

IplImage *ImageObject::ConvertToIplImage(cv::Mat mat)
{
	IplImage *img = new IplImage(mat);
	return img;
}

Vec3<double> ImageObject::ScalarToColor(double val)
{
	// double fColorMap[3][3] = {{0.960784314,0.498039216,0.011764706},{0,0,0},{0,0.462745098,0.88627451}};
	double fColorMap[5][3] = { { 0, 0, 1 }, { 0, 1, 1 }, { 0, 1, 0 }, { 1, 1, 0 }, { 1, 0, 0 } };	//Red->Blue
	// double fColorMap[4][3] = {{0.15,0.35,1.0},{1.0,1.0,1.0},{1.0,0.5,0.0},{0.0,0.0,0.0}};
	double v = val;
	if (val> 1.0) v = 1.0; if (val< 0.0) v = 0.0; v *= 4.0;
	int low = (int)floor(v), high = (int)ceil(v);
	double t = v - low;
	Vec3<double> color;
	color.x((fColorMap[low][0])*(1 - t) + (fColorMap[high][0])*t);
	color.y((fColorMap[low][1])*(1 - t) + (fColorMap[high][1])*t);
	color.z((fColorMap[low][2])*(1 - t) + (fColorMap[high][2])*t);
	return color;
}