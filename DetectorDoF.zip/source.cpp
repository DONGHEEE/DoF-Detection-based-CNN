#include <stdio.h>
#include <opencv2\opencv.hpp>
#include "DetectorDoFRegion.h"

void main(void)
{
	IplImage *img = cvLoadImage("img\\what-is-depth-of-field-1000x605.jpg");
	DetectorDoFRegion *detector = new DetectorDoFRegion(img);
	detector->Detection();
	
	cvWaitKey(0);
	cvDestroyAllWindows();
	cvReleaseImage(&img);
}