#include "DetectorDoFRegion.h"

DetectorDoFRegion::DetectorDoFRegion()
{
}

DetectorDoFRegion::DetectorDoFRegion(IplImage *source)
{
	m_Source = source;
	Show("Original", m_Source);
}

DetectorDoFRegion::~DetectorDoFRegion()
{
}

void DetectorDoFRegion::Smooth(void)
{
	double sigma = 1.5;
	cv::Mat sourceMat = ConvertToMat(m_Source);
	m_Blur = cvCreateImage(cvGetSize(m_Source), 8, 3);
	cv::Mat blurMat = ConvertToMat(m_Blur);
	cv::GaussianBlur(sourceMat, blurMat, cv::Size(0, 0), sigma);
	m_Blur = ConvertToIplImage(blurMat);
	Show("Blur", m_Blur); 
	cvSaveImage("save\\Blur.jpg", m_Blur);
}

void DetectorDoFRegion::Detection(void)
{
	Smooth();
	int maskSize = 15;
	m_DoF = cvCreateImage(cvGetSize(m_Source), 8, 3);
	cvSet(m_DoF, CV_RGB(255, 255, 255));
	vector<vector<double>> sumDiffArray;
	sumDiffArray.resize(m_Source->width);
	double maxDiff = -10000.0;

	for (int i = 0; i < m_Source->width; i++) {
		for (int j = 0; j < m_Source->height; j++) {
			double sumDiff = 0.0;
			int validPixels = 0;
			for (int mi = i - maskSize; mi < i + maskSize; mi++) {
				for (int mj = j - maskSize; mj < j + maskSize; mj++) {
					if (mi < 0 || mj < 0 || mi > m_Source->width - 1 || mj > m_Source->height - 1) {
						continue;
					}
					CvScalar color = cvGet2D(m_Source, mj, mi);
					CvScalar blurColor = cvGet2D(m_Blur, mj, mi);
					Vec3<double> colorVec(color.val[0], color.val[1], color.val[2]);
					Vec3<double> blurColorVec(blurColor.val[0], blurColor.val[1], blurColor.val[2]);
					sumDiff += (blurColorVec - colorVec).Length();
					validPixels++;
				}
			}
			sumDiff /= validPixels;
			maxDiff = max(maxDiff, sumDiff);
			sumDiffArray[i].push_back(sumDiff);
		}
	}

	for (int i = 0; i < m_Source->width; i++) {
		for (int j = 0; j < m_Source->height; j++) {
			sumDiffArray[i][j] /= maxDiff;
			Vec3<double> color = ScalarToColor(sumDiffArray[i][j]);
			color *= 255.0;
			//cvSet2D(m_DiffImg, j, i, CV_RGB(color.z(), color.y(), color.x()));
			double mag = sumDiffArray[i][j] * 255.0;
			cvSet2D(m_DoF, j, i, CV_RGB(mag, mag, mag));
		}
	}
	Show("DoF", m_DoF);
	cvSaveImage("save\\DoF.jpg", m_DoF);
}