#ifndef __IMAGE_OBJECT_H__
#define __IMAGE_OBJECT_H__

#pragma once
#include <opencv2\opencv.hpp>
#include "Vec3.h"

class ImageObject
{
public:
	ImageObject();
	~ImageObject();
public:
	void			Show(char *name, IplImage *img);
	void			Show(char *name, cv::Mat &mat);
	cv::Mat			ConvertToMat(IplImage *img);
	IplImage		*ConvertToIplImage(cv::Mat mat);
	Vec3<double>	ScalarToColor(double val);
};

#endif