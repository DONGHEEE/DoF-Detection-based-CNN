#ifndef __DETECTOR_DOF_REGION_H__
#define __DETECTOR_DOF_REGION_H__

#pragma once
#include <stdio.h>
#include <opencv2\opencv.hpp>
#include "ImageObject.h"
#include <vector>

using namespace std;

class DetectorDoFRegion : public ImageObject
{
public:
	IplImage *m_Source;
	IplImage *m_Blur;
	IplImage *m_DoF;
public:
	DetectorDoFRegion();
	DetectorDoFRegion(IplImage *source);
	~DetectorDoFRegion();
public:
	void	Smooth(void);
	void	Detection(void);
};

#endif